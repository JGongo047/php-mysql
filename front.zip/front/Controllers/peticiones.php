<?php 
//Se importa la clase usaurios, la cual tendrá las consultas a BD
require_once("../Class/Usuarios.php");

    //Empezaremos a realizar operaciones siempre y cuando haya un POST
    if(isset($_POST) && !empty($_POST))
    {

        //Se crea una instancia de la clase Usuarios, lo que permitirá acceder a sus métodos y atributos
        $obj = new Usuario();

        //Validamos quién nos hace el post, en este caso, si es el LOGIN, recibiremos los campos de correo y contraseña
        if(isset($_POST['login']))
        {

                //Se quitan los espacios con TRIM(), para limpiar un poco los campos que llegan del formulario.
                $correo = trim($_POST['correo']);
                $contrasena = trim($_POST['contrasena']);

                //Haciendo uso del objeto $obj , accedemos al método iniciarSesion y enviamos dos parámetros.
                $resultado =  $obj->iniciarSesion($correo, $contrasena);

                //Si el resultado es positivo, iniciamos sesión y redirigimos al usuario al dashboard principal
                if($resultado)
                {
                    session_start();
					$_SESSION['usuario'] = $correo;
                    header("Location:../Vistas/principal.php");
                }else{
                    echo "<script> 
					alert('Correo o Contraseña inválidos') 
					window.history.go(-1);
					</script>";
                }

        }else if(isset($_POST['registro']))
        {

            $nombre = trim($_POST['nombre']);
            $apellido = trim($_POST['apellido']);
            $fecha = trim($_POST['fechana']);
            $correo = trim($_POST['correo']);
            $contrasena = trim($_POST['contrasena']);

            
            $resultado = $obj->registrarUsuario($nombre, $apellido, $fecha, $correo, $contrasena);
       

            if($resultado)
            {
                echo "<script> 
					alert('Usuario registrado con exito') 
                    location.href='../Vistas/principal.php';
					</script>";
            }else{
                echo "<script> 
                alert('Error al crear usuario') 
                window.history.go(-1);
                </script>";
            }

        }else if(isset($_POST['actualizacion']))
        {

            $nombre = trim($_POST['nombre']);
            $apellido = trim($_POST['apellido']);
            $fecha = trim($_POST['fechana']);
            $correo = trim($_POST['correo']);
            $contrasena = trim($_POST['contrasena']);
            $id = trim($_POST['id']);


            
            $resultado = $obj->actualizarUsuario($nombre, $apellido, $fecha, $correo, $contrasena, $id);
       

            if($resultado)
            {
                echo "<script> 
					alert('Usuario actualizado con exito') 
                    location.href='../Vistas/principal.php';
					</script>";
            }else{
                echo "<script> 
                alert('Error al actualizar usuario') 
                window.history.go(-1);
                </script>";
            }

        }else if(isset($_POST['eliminacion']))
        {

            $id = trim($_POST['id']);
            $resultado = $obj->eliminarUsuario($id);

            if($resultado)
            {
                echo "<script> 
					alert('Usuario eliminado con exito') 
                    location.href='../Vistas/principal.php';
					</script>";
            }else{
                echo "<script> 
                alert('Error al eliminar usuario') 
                window.history.go(-1);
                </script>";
            }
          
        }else if(isset($_POST['cerrarsesion']))
        {
            session_start();
            session_destroy();
            $_SESSION['usuario'] = [];
            header("Location:../");
        }
    }else{
        header("Location:../");
    }


?>