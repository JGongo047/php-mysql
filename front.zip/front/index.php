<?php
 session_start();
 if(isset($_SESSION) &&  !empty($_SESSION['usuario']))
 {
     header("Location:Vistas/principal.php");
 }

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">
    <title>Front Gongo</title>
</head>
<body class="d-flex flex-column min-vh-100" style="overflow-x:hidden;">

    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
            <img src="img/logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
            Front Gongo
            </a>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-3 col-lg-3"></div>

            <div class="col-xs-12 col-md-6 col-lg-6">
                <div class="card mt-5">
                    <div class="card-header">
                        Inicio de Sesión
                    </div>
                    <div class="card-body">
                    <form method="POST" action="Controllers/peticiones.php">
                        <div class="mb-3">
                            <label for="correo" class="form-label">Correo</label>
                            <input required type="email" class="form-control" name="correo" aria-describedby="emailHelp">
                        </div>
                        <div class="mb-3">
                            <label for="contrasena" class="form-label">Contraseña</label>
                            <input required type="password" class="form-control" name="contrasena">
                        </div>
                        <button name="login" type="submit" class="btn btn-primary">Iniciar Sesión</button>
                    </form>
                    </div>
                </div>
            </div>

            <div class="col-xs-12 col-md-3 col-lg-3"></div>

        </div>

    </div>

    <footer class="mt-auto">
        <div class="row">
            <p class="text-center">© 2023 FrontGongo.com</p>
        </div>
    </footer>
    
</body>
</html>