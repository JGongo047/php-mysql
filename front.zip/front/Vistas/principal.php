<?php 
    session_start();
    if(isset($_SESSION) &&  empty($_SESSION['usuario']))
    {
        header("Location:../");
    }

    require_once("../Class/Usuarios.php");
    $obj = new Usuario();
    $listaUsuarios = $obj->obtenerUsuarios();

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <title>Principal</title>
</head>
<body class="d-flex flex-column min-vh-100" style="overflow-x:hidden;">

    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
            <img src="../img/logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
            Front Gongo
            </a>
            <div class="float-end">
                        <p><?php echo $_SESSION['usuario'] ?></p>
               
            </div>
        </div>
    </nav>

    <div class="container-fluid">

    <div class="float-end">
             <form action="../Controllers/peticiones.php" method="POST">
                <button name="cerrarsesion" class="btn btn-danger">Cerrar Sesión</button>
            </form>
    </div>
        <div class="row mt-5">
            <h3 class="text-center">Listado de Usuarios</h3>
                <div class="col-xs-12 col-md-2 col-lg-2"></div>
                <div class="col-xs-12 col-md-8 col-lg-8">

                <div class="float-end">
                    <a href="registro.php" class="btn btn-success">Crear Usuario</a>
                </div>
            

                        <table class="table table-striped table-inverse table-responsive">
                            <thead class="thead-inverse">
                                <tr>
                                    <th>Nombre</th>
                                    <th>Apellido</th>
                                    <th>Fecha Nacimiento</th>
                                    <th>Correo</th>
                                    <th>Editar</th>
                                    <th>Eliminar</th>

                                </tr>
                                </thead>
                                <tbody>
                                    <?php for($i=0; $i < count($listaUsuarios); $i++){ ?>
                                        <tr>
                                            <td scope="row"><?php echo $listaUsuarios[$i]["nombre"] ?></td>
                                            <td scope="row"><?php echo $listaUsuarios[$i]["apellido"] ?></td>
                                            <td scope="row"><?php echo $listaUsuarios[$i]["fecha_nacimiento"] ?></td>
                                            <td scope="row"><?php echo $listaUsuarios[$i]["correo"] ?></td>
                                            <td scope="row"><a href="edicion.php?id=<?php echo $listaUsuarios[$i]['id']?>&nombre=<?php echo $listaUsuarios[$i]['nombre']?>&apellido=<?php echo $listaUsuarios[$i]['apellido']?>&fecha=<?php echo $listaUsuarios[$i]['fecha_nacimiento']?>&correo=<?php echo $listaUsuarios[$i]['correo']?>" class="btn btn-info text-white">Editar</a></td>
                                            <td scope="row">
                                            <form action="../Controllers/peticiones.php" method="POST">
                                                <input type="hidden" name="id" value="<?php echo $listaUsuarios[$i]['id'] ?>">
                                                <button name="eliminacion" class="btn btn-danger">Eliminar</button>
                                            </form>
                                            </td>

                                        </tr>
                                    <?php } ?>
                                </tbody>
                        </table>
                </div>
                <div class="col-xs-12 col-md-2 col-lg-2"></div>


        </div>

    </div>

    <footer class="mt-auto">
        <div class="row">
            <p class="text-center">© 2023 FrontGongo.com</p>
        </div>
    </footer>
    
</body>
</html>