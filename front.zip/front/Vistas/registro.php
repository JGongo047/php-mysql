<?php
 //Se inicia sesión, si no existe, se redirige al Login
 session_start();
 if(isset($_SESSION) &&  empty($_SESSION['usuario']))
 {
     header("Location:../");
 }

 ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <title>Registro de Usuarios</title>
</head>
<body class="d-flex flex-column min-vh-100" style="overflow-x:hidden;">

    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
            <img src="../img/logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
            Front Gongo
            </a>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row mt-5">
            <div class="float-start">
                <a href="principal.php" class="btn btn-info text-white">Volver</a>
            </div>
            <h3 class="text-center">Registro de Usuarios</h3>
                <div class="col-xs-12 col-md-4 col-lg-4"></div>
                <div class="col-xs-12 col-md-4 col-lg-4">

                <form action="../Controllers/peticiones.php" method="POST">

                    <div class="form-group mt-3">
                        <label for="">Nombre</label>
                        <input required type="text" class="form-control" name="nombre">
                    </div>
                    <div class="form-group mt-3">
                        <label for="">Apellido</label>
                        <input required type="text" class="form-control" name="apellido">
                    </div>
                    <div class="form-group mt-3">
                        <label for="">Fecha de Nacimiento</label>
                        <input required type="date" class="form-control" name="fechana">
                    </div>
                    <div class="form-group mt-3">
                        <label for="">Correo</label>
                        <input required type="email" class="form-control" name="correo">
                    </div>
                    <div class="form-group mt-3">
                        <label for="">Contraseña</label>
                        <input required type="password" class="form-control" name="contrasena">
                    </div>
                    <div class="form-group mt-3">
                        <button name="registro" type="submit" class="btn btn-success">Registrar Usuario</button>
                    </div>

                </form>

    
                      
                </div>
                <div class="col-xs-12 col-md-4 col-lg-4"></div>


        </div>

    </div>

    <footer class="mt-auto">
        <div class="row">
            <p class="text-center">© 2023 FrontGongo.com</p>
        </div>
    </footer>
    
</body>
</html>