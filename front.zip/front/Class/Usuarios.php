<?php 

	require_once('conexionBD.php');

	class Usuario{

		private $correo;
		private $contrasena;


		private $cone; 
	
	
		public function __construct(){
			$this->cone = new Conexion();

		}

		public function iniciarSesion($correo,$contrasena){

			$sql = "SELECT * FROM usuarios WHERE correo = '$correo' AND contrasena = '$contrasena' ";
			$query = $this->cone->prepare($sql);
			$query->execute();	
			$result=$query->fetchAll(\PDO::FETCH_ASSOC);
		
			return $result;
		}

		public function obtenerUsuarios(){

			$sql = "SELECT * FROM usuarios";
			$query = $this->cone->prepare($sql);
			$query->execute();	
			$result=$query->fetchAll(\PDO::FETCH_ASSOC);
			return $result;
		}


		public function registrarUsuario($nombre, $apellido, $fecha, $correo, $contrasena ){
			$id = NULL;
			$sql = "INSERT INTO usuarios (nombre, apellido, fecha_nacimiento, correo, contrasena) VALUES ('$nombre', '$apellido', '$fecha', '$correo', '$contrasena')";
			$query = $this->cone->prepare($sql);
			$result = $query->execute();
		
			return $result;

		}

		
		public function actualizarUsuario($nombre, $apellido, $fecha, $correo, $contrasena, $id ){

		
			$sql = "UPDATE  usuarios 
			SET nombre = '$nombre', 
			apellido = '$apellido', 
			fecha_nacimiento = '$fecha', 
			correo='$correo', 
			contrasena='$contrasena' 
			WHERE id = '$id'";
        	$cone = $this->cone;
        	$query = $cone->prepare($sql);
        	$result = $query->execute();
            
        	return $result;

		}

		public function eliminarUsuario($id){

		
			$sql = "DELETE FROM  usuarios WHERE id = '$id'";
        	
        	$cone = $this->cone;
        	$query = $cone->prepare($sql);
        	$result = $query->execute();
            
        	return $result;

		}

	

	}
 ?>	